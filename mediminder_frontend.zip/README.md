# MediMinder Frontend

A single-file, elderly-friendly medicine reminder interface (HTML, Tailwind CSS and vanilla JavaScript).

## Features
- Tamil / English language switch
- Voice reminders (Web Speech API)
- Home dashboard with Morning, Afternoon, Evening and Night schedule
- Confirm and Snooze actions with progress ring
- Prescription upload with simulated AI extraction
- Settings: voice, caregiver escalation, delay, caregiver contact, offline test

## Run
1. Unzip the folder.
2. Open `index.html` in Chrome, Edge or Firefox (double-click it).

Internet access is needed once to load Tailwind CSS from cdn.tailwindcss.com.

## Notes
- Data is kept in memory only and resets on reload. To connect to the backend in
  `mediminder_backend`, replace the in-page data with calls to its `/api` endpoints.
- Prescription extraction is simulated.
